package com.example.shopping_cart_20;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

public class profile extends AppCompatActivity {
    int count=0;
    DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReferenceFromUrl("https://shopping-cart-bd683-default-rtdb.firebaseio.com/users");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        TextView fullname = findViewById(R.id.fullname);
        TextView mobile2 = findViewById(R.id.mobile2);
        EditText name_label = findViewById(R.id.name_label);
        EditText email_label = findViewById(R.id.email_label);
        EditText mobile_label = findViewById(R.id.mobile_label);
        TextView balance_label=findViewById(R.id.payment_desc);
        TextView spent_label=findViewById(R.id.spent_desc);
        Button button = findViewById(R.id.update);
        Button button2 = findViewById(R.id.cancel);
        Intent intent = getIntent();
        // receive the value by getStringExtra() method and
        // key must be same which is send by first activity
        String name = intent.getStringExtra("name_key");
        String mobile = intent.getStringExtra("mobile_key");
        String email = intent.getStringExtra("email_key");
        String balance = intent.getStringExtra("balance_key");
        String spent = intent.getStringExtra("spent_key");
        balance_label.setText(balance);
        spent_label.setText(spent);
        fullname.setText(name);
        mobile2.setText(mobile);
        name_label.setText(name);
        email_label.setText(email);
        mobile_label.setText(mobile);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!name.equals(name_label.getText().toString())){
                    databaseReference.child(mobile).child("name").setValue(name_label.getText().toString());
                    count=count+1;
                }
                if (!email.equals(email_label.getText().toString())){
                    databaseReference.child(mobile).child("email").setValue(email_label.getText().toString());
                    count=count+1;

                }
                if(count==0){
                    Toast.makeText(profile.this, "Please make changes", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(profile.this, "Updated successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(getApplicationContext(),Homepage.class);
                    intent.putExtra("name_key", name_label.getText().toString());
                    intent.putExtra("email_key", email_label.getText().toString());
                    intent.putExtra("mobile_key", mobile_label.getText().toString());
                    startActivity(intent);
                    count=0;
                    finish();
                }

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),Homepage.class);
                intent.putExtra("name_key", name_label.getText().toString());
                intent.putExtra("email_key", email_label.getText().toString());
                intent.putExtra("mobile_key", mobile_label.getText().toString());
                startActivity(intent);
                finish();
            }
        });
    }
    }