package com.example.shopping_cart_20;
public class User {
    String name, quantity, price;
    User(){

    }

    public User(String name, String quantity, String price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public String getName() {
        return name;
    }
    public String getQuantity() {
        return quantity;
    }
    public String getPrice() {
        return price;
    }
}


