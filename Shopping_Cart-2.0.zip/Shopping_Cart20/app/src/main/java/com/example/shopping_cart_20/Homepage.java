package com.example.shopping_cart_20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Homepage extends AppCompatActivity {
    DatabaseReference databaseReference2= FirebaseDatabase.getInstance().getReferenceFromUrl("https://shopping-cart-bd683-default-rtdb.firebaseio.com/");

    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        final TextView p2=findViewById(R.id.p1);
        final ImageView logout=findViewById(R.id.logout1);
        ImageView contact=findViewById(R.id.contact2);
        Intent intent = getIntent();
        // receive the value by getStringExtra() method and
        // key must be same which is send by first activity
        String name = intent.getStringExtra("name_key");
        String mobile=intent.getStringExtra("mobile_key");
        String email=intent.getStringExtra("email_key");
        // display the string into textView
        p2.setText(name);
        ImageView imageView=findViewById(R.id.img3);
        ImageView profile1=findViewById(R.id.profile);
        Button button=findViewById(R.id.button2);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),contact.class);
                intent.putExtra("name_key", name);
                intent.putExtra("mobile_key", mobile);
                intent.putExtra("email_key", email);
                startActivity(intent);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference2.child("id").child("id0").child("id1").setValue("0000000000");
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),userlist.class);
                intent.putExtra("mobile_key", mobile);
                startActivity(intent);
                finish();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),userlist.class);
                intent.putExtra("mobile_key", mobile);
                startActivity(intent);
                finish();
            }
        });
        profile1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference=FirebaseDatabase.getInstance().getReference("users");
                databaseReference.child(mobile).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        DataSnapshot dataSnapshot=task.getResult();
                        String balance=String.valueOf(dataSnapshot.child("balance").getValue());
                        String spent=String.valueOf(dataSnapshot.child("spent").getValue());
                        Intent intent=new Intent(getApplicationContext(),profile.class);
                        intent.putExtra("name_key", name);
                        intent.putExtra("mobile_key", mobile);
                        intent.putExtra("email_key", email);
                        intent.putExtra("balance_key", balance);
                        intent.putExtra("spent_key", spent);
                        // start the Intent
                        startActivity(intent);
                        finish();
                    }
                });
            }
        });
    }
}