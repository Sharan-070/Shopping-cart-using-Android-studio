package com.example.shopping_cart_20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Register extends AppCompatActivity {
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://shopping-cart-bd683-default-rtdb.firebaseio.com/");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        final EditText name = findViewById(R.id.name1);
        final EditText email = findViewById(R.id.email);
        final EditText mobile = findViewById(R.id.mobile);
        final EditText password = findViewById(R.id.password);
        final EditText con_pass = findViewById(R.id.con_pass);
        final Button register = findViewById(R.id.register);
        final TextView login1 = findViewById(R.id.login_now);
        register.setOnClickListener(v -> {
            final String name1 = name.getText().toString();
            final String email1 = email.getText().toString();
            final String mobile1 = mobile.getText().toString();
            final String password1 = password.getText().toString();
            final String con_pass1 = con_pass.getText().toString();
            if (email1.isEmpty() && password1.isEmpty() && con_pass1.isEmpty() && mobile1.equals("") && name1.isEmpty()) {
                Toast.makeText(Register.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
            } else {
                databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.hasChild(mobile1)) {
                            Toast.makeText(Register.this, "Email already exists", Toast.LENGTH_SHORT).show();
                        } else {
                            boolean check=validation(name1,email1,mobile1,password1,con_pass1);
                            if(check==true){
                                Toast.makeText(Register.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                                databaseReference.child("users").child(mobile1).child("name").setValue(name1);
                                databaseReference.child("users").child(mobile1).child("email").setValue(email1);
                                databaseReference.child("users").child(mobile1).child("mobile").setValue(mobile1);
                                databaseReference.child("users").child(mobile1).child("password").setValue(password1);
                                databaseReference.child("users").child(mobile1).child("balance").setValue("5000");
                                databaseReference.child("users").child(mobile1).child("spent").setValue("0");
                                finish();
                            }
                        }
                    }
                    private Boolean validation(String name1, String email1, String mobile1, String password1, String con_pass1) {
                        if(name.length()==0){
                            name.requestFocus();
                            name.setError("Field cannot be empty");
                            return false;
                        }
                        else if(!name1.matches("[a-zA-Z]+")){
                            name.requestFocus();
                            name.setError("Invalid name");
                            return false;
                        }
                        else if(email.length()==0){
                            email.requestFocus();
                            email.setError("Field cannot be empty");
                            return false;
                        }
                        else if(!email1.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){
                            email.requestFocus();
                            email.setError("Invalid email address");
                            return false;
                        }
                        else if(mobile.length()==0){
                            mobile.requestFocus();
                            mobile.setError("Field cannot be empty");
                            return false;
                        }
                        else if(!mobile1.matches("^[0-9]{10}$")){
                            mobile.requestFocus();
                            mobile.setError("Invalid mobile number");
                            return false;
                        }
                        else if(password1.length()<5){
                            password.requestFocus();
                            password.setError("Include Minimum 5 characters");
                            return false;
                        }
                        else if (!password1.equals(con_pass1)) {
                            Toast.makeText(Register.this, "Password Mismatch", Toast.LENGTH_SHORT).show();
                            return false;
                        }
                        else{
                            return true;
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
        });
        login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Register.this, Login.class));
            }
        });

    }
}